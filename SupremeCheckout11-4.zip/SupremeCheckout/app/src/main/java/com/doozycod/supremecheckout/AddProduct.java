package com.doozycod.supremecheckout;

import android.app.Activity;
import android.app.Dialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doozycod.supremecheckout.Helper.DbHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AddProduct extends AppCompatActivity {
    List<String> categoriesList = new ArrayList<String>();
    List<String> productList = new ArrayList<String>();
    List<String> colorList = new ArrayList<String>();
    List<String> sizeList = new ArrayList<String>();
    List<String> size_id_List = new ArrayList<String>();
    List<String> color_id_List = new ArrayList<String>();
    List<String> product_id_list = new ArrayList<String>();

    String allColors = "";
    String color_id = "";
    DbHelper dbHelper;
    ArrayAdapter<String> arrayAdapter;
    String product_id, product_name;
    String pro_id_from_list, color_id_from_list, size_id_from_list;
    SQLiteDatabase db;
    TextView tv_category, tv_product, tv_color, tv_size;
    String url;
    String color_name, json_size, size_id = "";
    Button saveProductBTN;
    LinearLayout select_category_, select_product_, select_color_, select_size_;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);


        dbHelper = new DbHelper(this);


        tv_category = findViewById(R.id.tv_select_category);
        tv_product = findViewById(R.id.tv_select_product);
        tv_color = findViewById(R.id.tv_select_color);
        tv_size = findViewById(R.id.tv_select_size);

        select_category_ = findViewById(R.id.spinner_layout_category);
        select_product_ = findViewById(R.id.spinner_layout_product);
        select_color_ = findViewById(R.id.spinner_layout_color);
        select_size_ = findViewById(R.id.spinner_layout_size);
        saveProductBTN = findViewById(R.id.btn_save_product_details);

//        Array List of category
        categoriesList = new ArrayList<String>();
        categoriesList.add("Jackets");
        categoriesList.add("T-Shirts");
        categoriesList.add("Shirts");
        categoriesList.add("Sweatshirts");
        categoriesList.add("Tops/Sweaters");
        categoriesList.add("Pants");
        categoriesList.add("Shorts");
        categoriesList.add("Hats");
        categoriesList.add("Bags");
        categoriesList.add("Accessories");


        select_category_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(AddProduct.this);
                tv_product.setText("Select Product");

            }
        });
        select_product_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialogProducts(AddProduct.this);
                tv_color.setText("Select Color");
            }
        });
        select_color_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialogColor(AddProduct.this);
                tv_size.setText("Select Size");
            }
        });
        select_size_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialogSize(AddProduct.this);
            }
        });
        saveProductBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.save_product_from_settings(tv_category.getText().toString(), tv_product.getText().toString(), tv_color.getText().toString(), tv_size.getText().toString(), color_id_from_list, pro_id_from_list, size_id_from_list);

                SQLiteDatabase db = dbHelper.getReadableDatabase();

                String sql = "select * from " + DbHelper.TABLE_SPINNER_PRODUCT;
                Cursor cursor = db.rawQuery(sql, null);

                if (cursor.moveToFirst()) {
                    do {
                        String cat_ = cursor.getString(cursor.getColumnIndex("category_name"));
                        String pro_n = cursor.getString(cursor.getColumnIndex("product_name"));
                        String pro_c = cursor.getString(cursor.getColumnIndex("product_color"));
                        String pro_s = cursor.getString(cursor.getColumnIndex("product_size"));
                        String size_id = cursor.getString(cursor.getColumnIndex("size_id"));
                        Log.e("Save BUTTON FETCH ::", cat_ + pro_n + pro_c + pro_s + size_id);

                    } while (cursor.moveToNext());

                    Toast.makeText(AddProduct.this, "Product Details Saved!", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }


    public void Json_Method_For_Product(String url, final String product_id) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    allColors = "";
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("styles");

                    for (int index = 0; index < jsonArray.length(); index++) {

                        JSONObject parm = jsonArray.getJSONObject(index);
                        color_name = parm.getString("name");
                        color_id = parm.getString("id");

                        Log.e("Color Product:::", color_name);
                        color_id_List.add(color_id);
                        colorList.add(color_name);
                        if (allColors.equals("")) {
                            allColors = color_name + ",";
                            Log.e("IF COLORS", allColors);
                        } else if (index == jsonArray.length() - 1) {

                            allColors = allColors + color_name;
                            Log.e("ELSE IF COLORS", allColors);

                        } else {
                            allColors = allColors + color_name + ",";
                            Log.e("ELSE COLORS", allColors);
                        }
                        Log.e("ALL COLORS", allColors);

                        JSONArray jsonSizeArray = parm.getJSONArray("sizes");

                        jsonArraySizeFunc(jsonSizeArray);

                    }


                } catch (JSONException e) {

                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Response Error ::", error.toString());
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void showDialog(Activity activity) {

        final Dialog dialog = new Dialog(activity);
        // dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_spinner);


        ListView listView = dialog.findViewById(R.id.recycler_list_view);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.product_list_view, R.id.tv_select_product_recycler, categoriesList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                tv_category.setText(categoriesList.get(position));

                SQLiteDatabase db = dbHelper.getReadableDatabase();

//        String for query
                String query = "select * from " + DbHelper.TABLE_ALL_PRODUCTS + " where " + "category_name" + " = '" + categoriesList.get(position) + "'";

//      Creating cursor object to use query to get the data from table
                Cursor cur = db.rawQuery(query, null);


//        Condition for set the data
                if (cur.moveToFirst()) {
                    productList.clear();
                    do {
                        product_id = cur.getString(cur.getColumnIndex("product_id"));
                        product_name = cur.getString(cur.getColumnIndex("product_name"));
                        product_id_list.add(product_id);
                        productList.add(product_name);
                        Log.e("Cursor On item:::", product_id);

                    } while (cur.moveToNext());


                } else {

                    Log.e("Empty", "Nulll");
                }
                dialog.dismiss();
            }
        });

        dialog.show();

    }

    public void showDialogProducts(Activity activity) {

        final Dialog dialog = new Dialog(activity);
        // dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_spinner);


        ListView listView = dialog.findViewById(R.id.recycler_list_view);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.product_list_view, R.id.tv_select_product_recycler, productList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e("Dialog", productList.get(position));
                tv_product.setText(productList.get(position));
                pro_id_from_list = product_id_list.get(position);
                db = dbHelper.getReadableDatabase();
                String select_product_id_query = "select * from " + DbHelper.TABLE_ALL_PRODUCTS + " where " + "product_name" + " = '" + productList.get(position) + "'";
                Cursor cursor = db.rawQuery(select_product_id_query, null);

                if (cursor.moveToNext()) {
                    colorList.clear();
                    product_id = cursor.getString(cursor.getColumnIndex("product_id"));
                    Log.e("Product ID:::", product_id);

                }
                url = "https://www.supremenewyork.com/shop/" + product_id + ".json";
                Log.e("URL :::", url);
                Json_Method_For_Product(url, product_id);

                dialog.dismiss();
            }
        });

        dialog.show();

    }

    public void showDialogColor(Activity activity) {

        final Dialog dialog = new Dialog(activity);
        // dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_spinner);


        ListView listView = dialog.findViewById(R.id.recycler_list_view);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.product_list_view, R.id.tv_select_product_recycler, colorList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e("Dialog", colorList.get(position));
                tv_color.setText(colorList.get(position));
                color_id_from_list = color_id_List.get(position);
                dialog.dismiss();
            }
        });

        dialog.show();

    }

    public void jsonArraySizeFunc(JSONArray jsonSizeArray) {
        try {
            sizeList.clear();
            for (int i = 0; i <= jsonSizeArray.length(); i++) {
                JSONObject jsonSizeObject = jsonSizeArray.getJSONObject(i);
                json_size = jsonSizeObject.getString("name");
                size_id = jsonSizeObject.getString("id");

                size_id_List.add(size_id);
                sizeList.add(json_size);

            }
        } catch (JSONException e) {

            e.printStackTrace();
        }

    }

    public void showDialogSize(Activity activity) {

        final Dialog dialog = new Dialog(activity);
        // dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.custom_spinner);


        ListView listView = dialog.findViewById(R.id.recycler_list_view);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.product_list_view, R.id.tv_select_product_recycler, sizeList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e("Dialog", sizeList.get(position));
                tv_size.setText(sizeList.get(position));
                size_id_from_list = size_id_List.get(position);

                dialog.dismiss();

            }
        });

        dialog.show();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }
}