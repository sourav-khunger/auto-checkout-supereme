package com.doozycod.supremecheckout.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.doozycod.supremecheckout.Helper.DbHelper;
import com.doozycod.supremecheckout.Helper.Model;
import com.doozycod.supremecheckout.R;

import java.util.List;

public class SavedProductAdapter extends RecyclerView.Adapter<SavedProductAdapter.RecyclerHolder> {
    Context context;
    static List<Model> modelList;
    DbHelper dbHelper;

    public SavedProductAdapter(Context context, List<Model> modelList, DbHelper dbHelper) {
        this.context = context;
        this.modelList = modelList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public SavedProductAdapter.RecyclerHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.saved_product_recycler_view_item, viewGroup, false);

        return new RecyclerHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SavedProductAdapter.RecyclerHolder recyclerHolder, final int i) {

        recyclerHolder.tv_category_rv.setText(modelList.get(i).getProductCategory());
        recyclerHolder.tv_product_name_rv.setText(modelList.get(i).getProductName());
        recyclerHolder.tv_product_color_rv.setText(modelList.get(i).getProductColor());
        recyclerHolder.tv_product_size_rv.setText(modelList.get(i).getProductSize());

        recyclerHolder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, modelList.get(recyclerHolder.getAdapterPosition()).getProductName()+" is Removed!", Toast.LENGTH_SHORT).show();
                dbHelper.deleteEntry(modelList.get(recyclerHolder.getAdapterPosition()).getProduct_id());
                modelList.remove(recyclerHolder.getAdapterPosition());
                notifyItemRemoved(recyclerHolder.getAdapterPosition());
                notifyDataSetChanged();

            }
        });
    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    class RecyclerHolder extends RecyclerView.ViewHolder {

        TextView tv_category_rv, tv_product_name_rv, tv_product_color_rv, tv_product_size_rv;
        RelativeLayout relativeLayout;

        public RecyclerHolder(@NonNull View itemView) {
            super(itemView);
            relativeLayout = itemView.findViewById(R.id.delete_btn);

            tv_category_rv = itemView.findViewById(R.id.tv_category_recycler_item);
            tv_product_name_rv = itemView.findViewById(R.id.tv_Product_name_recycler_item);
            tv_product_color_rv = itemView.findViewById(R.id.tv_product_color_recycler_item);
            tv_product_size_rv = itemView.findViewById(R.id.tv_product_size_recycler_item);


        }
    }
}
