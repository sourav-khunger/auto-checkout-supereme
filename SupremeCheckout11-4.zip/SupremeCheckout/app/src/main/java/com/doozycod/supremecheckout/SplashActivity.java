package com.doozycod.supremecheckout;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doozycod.supremecheckout.Helper.DbHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SplashActivity extends AppCompatActivity {
    public static final int SPLASH_DELAY = 4000;
    List<String> colorList = new ArrayList<String>();
    List<String> sizeList = new ArrayList<String>();
    List<String> in_stockList = new ArrayList<String>();
    String product_name;
    String query;
    String product_id;
    String product_price;
    String category_name;
    String sales_price;
    String allColorID = "";
    String in_stock;
    Cursor c;
    String size_ID;
    DbHelper dbHelper;
    String URL = "";
    String allColors = "";
    String allSizes = "";
    String color_name, json_size = "", color_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        dbHelper = new DbHelper(this);
        String url = "https://www.supremenewyork.com/mobile_stock.json";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

//                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                jsonjackets(response);
                jsonTshirts(response);
                jsonShirts(response);
                jsonSweatShirts(response);
                jsonTops(response);
                jsonPsupreme(response);
                jsonShorts(response);
                jsonHats(response);
                jsonBags(response);
                jsonAccessories(response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(SplashActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashActivity.this, MainActivity
                        .class));
                finish();
            }
        }, SPLASH_DELAY);
    }

    public void jsonjackets(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");
            JSONArray jsonArray = jsonfinal.getJSONArray("Jackets");


//                    Jackets

            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject parm = jsonArray.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonBags(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                  JsonBags

            JSONArray jsonBags = jsonfinal.getJSONArray("Bags");
            for (int i = 0; i < jsonBags.length(); i++) {

                JSONObject parm = jsonBags.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonPsupreme(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                  Pants
            JSONArray jsonPants = jsonfinal.getJSONArray("Pants");
            //                    Jackets

            for (int i = 0; i < jsonPants.length(); i++) {

                JSONObject parm = jsonPants.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonHats(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

            //                  JsonHats
            JSONArray jsonHats = jsonfinal.getJSONArray("Hats");

            //                    Jackets

            for (int i = 0; i < jsonHats.length(); i++) {

                JSONObject parm = jsonHats.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonAccessories(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                  JsonAccessories

            JSONArray jsonAccessories = jsonfinal.getJSONArray("Accessories");
            for (int i = 0; i <= jsonAccessories.length(); i++) {

                JSONObject parm = jsonAccessories.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonTops(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                  JsonTops

            JSONArray jsonTops = jsonfinal.getJSONArray("Tops/Sweaters");

            for (int i = 0; i <= jsonTops.length(); i++) {

                JSONObject parm = jsonTops.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonSweatShirts(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                    jsonSweatshirts

            JSONArray jsonSweatshirts = jsonfinal.getJSONArray("Sweatshirts");

            for (int i = 0; i <= jsonSweatshirts.length(); i++) {

                JSONObject parm = jsonSweatshirts.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonTshirts(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                    jsonTshirts

            JSONArray jsonTshirts = jsonfinal.getJSONArray("T-Shirts");

            for (int i = 0; i <= jsonTshirts.length(); i++) {

                JSONObject parm = jsonTshirts.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonShirts(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                    jsonTshirts

            JSONArray jsonShirts = jsonfinal.getJSONArray("Shirts");

            for (int i = 0; i <= jsonShirts.length(); i++) {

                JSONObject parm = jsonShirts.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void jsonShorts(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONObject jsonfinal = jsonObject.getJSONObject("products_and_categories");

//                    jsonTshirts

            JSONArray jsonShorts = jsonfinal.getJSONArray("Shorts");

            for (int i = 0; i <= jsonShorts.length(); i++) {

                JSONObject parm = jsonShorts.getJSONObject(i);

                product_id = parm.getString("id");
                category_name = parm.getString("category_name");
                product_name = parm.getString("name");
                product_price = parm.getString("price");
                sales_price = parm.getString("sale_price");

                URL = "https://www.supremenewyork.com/shop/" + product_id + ".json";

                if (getCount() == 0) {
                    dbHelper.insert_product(category_name, product_name, product_id, product_price, sales_price, "", "");
                }

                fetchProductDetailby_ID(URL, product_id);


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    private void fetchProductDetailby_ID(String url, final String product_id) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    allColors = "";
                    allColorID = "";
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("styles");

                    for (int index = 0; index < jsonArray.length(); index++) {

                        JSONObject parm = jsonArray.getJSONObject(index);
                        color_name = parm.getString("name");
                        color_id = parm.getString("id");

                        JSONArray jsonSizeArray = parm.getJSONArray("sizes");
//                        Log.e("JSON SIZE ARRAY ____>", jsonSizeArray.toString());


                        if (getCountforSize() == 0) {
                            dbHelper.save_product_size(color_id, color_name, "");
                        }
                        jsonArraySizeFunc(jsonSizeArray, color_id);

                        colorList.add(color_name);

                        if (allColors.equals("") && allColorID.equals("")) {

                            if (index == jsonArray.length() - 1) {
                                allColorID = allColorID + color_id;
                                allColors = allColors + color_name;
                            } else {
                                allColors = color_name + ",";
                                allColorID = color_id + ",";
                            }


                        } else if (index == jsonArray.length() - 1) {

                            allColorID = allColorID + color_id;
                            allColors = allColors + color_name;


                        } else if (allColors.equals("") && allColorID.equals("") && index == jsonArray.length() - 1) {
                            allColorID = allColorID + color_id;
                            allColors = allColors + color_name;
                        } else {
                            allColorID = allColorID + color_id + ",";
                            allColors = allColors + color_name + ",";
                        }


                    }
                    addcolorsInTable(product_id, allColors, allColorID);
//                    Log.e("added color and ids ======>", allColors + "&&&&&" + allColorID);


                } catch (JSONException e) {

                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Response Error ::", error.toString());
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void jsonArraySizeFunc(JSONArray jsonSizeArray, String color_id) {
        try {
//            sizeList.clear();
            allSizes = "";
            for (int i = 0; i < jsonSizeArray.length(); i++) {

                JSONObject jsonSizeObject = jsonSizeArray.getJSONObject(i);

                json_size = jsonSizeObject.getString("name");
                in_stock = jsonSizeObject.getString("stock_level");
                sizeList.add(json_size);
                in_stockList.add(in_stock);

                if (allSizes.equals("")) {

                    if (i == jsonSizeArray.length() - 1) {
                        allSizes = allSizes + json_size;
//                        dbHelper.update_size_in_table(color_id, allSizes);
                    } else {

                        allSizes = json_size + ",";
                    }
//                    Log.e("IF Size", i + "======>" + allSizes);

                } else if (i == jsonSizeArray.length() - 1) {

                    allSizes = allSizes + json_size;

                } else {
                    allSizes = allSizes + json_size + ",";
//                    Log.e("IF Size", i + "======>" + allSizes);
                }
                dbHelper.update_size_in_table(color_id, allSizes);

            }
        } catch (JSONException e) {

            e.printStackTrace();
        }

    }

    //    check if Product is available in database or not
    public int getCount() {
        c = null;
        SQLiteDatabase db = null;
        try {
            db = dbHelper.getReadableDatabase();

            query = "select * from " + DbHelper.TABLE_ALL_PRODUCTS + " where product_id = ?";

            c = db.rawQuery(query, new String[]{product_id});
            if (c.moveToFirst()) {
                return c.getInt(0);
            }
            return 0;
        } finally {
            if (c != null) {
//                c.close();
            }
            if (db != null) {
//                db.close();
            }
        }
    }

    //    check if Product is available in database or not
    public int getCountforSize() {
        c = null;
        SQLiteDatabase db = null;
        try {
            db = dbHelper.getReadableDatabase();

            query = "select * from " + DbHelper.TABLE_FOR_PRODUCT_SIZE + " where color_ids = ?";

            c = db.rawQuery(query, new String[]{color_id});
            if (c.moveToFirst()) {
                return c.getInt(0);
            }
            return 0;
        } finally {
            if (c != null) {
//                c.close();
            }
            if (db != null) {
//                db.close();
            }
        }
    }

    public void addcolorsInTable(String product_id, String allColors, String allColorID) {

        dbHelper.update_product(product_id, allColors, allColorID);


        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "select * from " + DbHelper.TABLE_ALL_PRODUCTS;
        Cursor cursor = db.rawQuery(query, null);


        int size_of_cusror = cursor.getCount();
        Log.e("size_of_cusror===>", size_of_cusror + "");


    }

}
