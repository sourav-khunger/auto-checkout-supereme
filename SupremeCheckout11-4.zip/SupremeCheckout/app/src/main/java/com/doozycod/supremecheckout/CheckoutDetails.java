package com.doozycod.supremecheckout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckoutDetails extends AppCompatActivity {
    EditText user_name, emailEditText, phoneEditText, address_EditText, address_EditText2, address_EditText3, city_EditText, postal_Code_EditText, card_no_EditText, cvv_Edittext;
    Button payNow_btn;
    RelativeLayout select_country, select_card;
    TextView select_Month, select_year, select_card_tv, select_country_tv;
    AlertDialog alertDialog1;
    CharSequence[] countryList = {"UK",
            "UK (N. IRELAND)",
            "AUSTRIA",
            "BELARUS",
            "BELGIUM",
            "BULGARIA",
            "CROATIA",
            "CZECH REPUBLIC",
            "DENMARK",
            "ESTONIA",
            "FINLAND",
            "FRANCE",
            "GERMANY",
            "GREECE",
            "HUNGARY",
            "ICELAND",
            "IRELAND",
            "ITALY",
            "LATVIA",
            "LITHUANIA",
            "LUXEMBOURG",
            "MONACO",
            "NETHERLANDS",
            "NORWAY",
            "POLAND",
            "PORTUGAL",
            "ROMANIA",
            "RUSSIA",
            "SLOVAKIA",
            "SLOVENIA",
            "SPAIN",
            "SWEDEN",
            "SWITZERLAND",
            "TURKEY"};
    CharSequence[] monthList = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
    CharSequence[] yearList = {"2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029"};
    CharSequence[] cardTypeList = {"Visa", "American Express", "Mastercard", "Solo",};
    CharSequence[] cardTypeList_id = {"visa", "american_express", "mastercard", "solo",};

    CharSequence[] countryCode_list = {"GB", "NB", "AT", "BY", "BE", "BG", "HR", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IS", "IE", "IT", "LV", "LT",
            "LU", "MC", "NL", "NO", "PL", "PT", "RO", "RU", "SK", "SI", "ES", "SE", "CH", "TR"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        select_country_tv = findViewById(R.id.tv_select_country);
        select_card_tv = findViewById(R.id.tv_select_card);
        select_card = findViewById(R.id.select_card);
        select_year = findViewById(R.id.tv_select_card_year);
        select_Month = findViewById(R.id.tv_select_card_month);
        user_name = findViewById(R.id.user_name);
        select_country = findViewById(R.id.select_country);
        emailEditText = findViewById(R.id.user_email_id);
        payNow_btn = findViewById(R.id.pay_now);
        phoneEditText = findViewById(R.id.phone_no);
        address_EditText = findViewById(R.id.user_address);
        address_EditText2 = findViewById(R.id.user_address2);
        address_EditText3 = findViewById(R.id.user_address3);
        city_EditText = findViewById(R.id.user_city);
        postal_Code_EditText = findViewById(R.id.postal_code);
        card_no_EditText = findViewById(R.id.card_number);
        cvv_Edittext = findViewById(R.id.card_cvv);

        select_country.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRadioButtonDialog();
            }
        });


        select_Month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRadioButtonDialog_for_month();
            }
        });

        select_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRadioButtonDialog_for_card();
            }
        });
        select_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRadioButtonDialog_for_year();
            }
        });
        payNow_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentValidation();
            }
        });

    }

    private void showRadioButtonDialog() {

        // custom dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Select Country");


        builder.setSingleChoiceItems(countryList, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(CheckoutDetails.this, countryCode_list[which], Toast.LENGTH_SHORT).show();
                select_country_tv.setText(countryList[which]);
                alertDialog1.dismiss();
            }
        });
        alertDialog1 = builder.create();
        alertDialog1.show();

    }

    private void showRadioButtonDialog_for_month() {

        // custom dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Select Month");


        builder.setSingleChoiceItems(monthList, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(CheckoutDetails.this, monthList[which], Toast.LENGTH_SHORT).show();
                select_Month.setText(monthList[which]);
                alertDialog1.dismiss();
            }

        });
        alertDialog1 = builder.create();
        alertDialog1.show();

    }

    private void showRadioButtonDialog_for_year() {

        // custom dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Select year");


        builder.setSingleChoiceItems(yearList, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(CheckoutDetails.this, yearList[which], Toast.LENGTH_SHORT).show();
                select_year.setText(yearList[which]);
                alertDialog1.dismiss();
            }

        });
        alertDialog1 = builder.create();
        alertDialog1.show();

    }

    private void showRadioButtonDialog_for_card() {

        // custom dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Select Card Type");


        builder.setSingleChoiceItems(cardTypeList, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(CheckoutDetails.this, cardTypeList[which], Toast.LENGTH_SHORT).show();
                select_card_tv.setText(cardTypeList[which]);
                alertDialog1.dismiss();
            }

        });
        alertDialog1 = builder.create();
        alertDialog1.show();

    }

    private void paymentValidation() {

        String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +

                "\\@" +

                "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +

                "(" +

                "\\." +

                "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +

                ")+";
        String email = emailEditText.getText().toString();

        Matcher matcher = Pattern.compile(validemail).matcher(email);

        if (!user_name.getText().toString().contains(" ")) {
            user_name.setError("Enter Full Name");
            return;
        }
        if (!matcher.matches()) {
            emailEditText.setError(" Please Enter A Valid Email");
            return;

        }
        if (TextUtils.isEmpty(phoneEditText.getText().toString())) {
            phoneEditText.setError("Phone no can't be Empty");
            return;
        }
        if (address_EditText.getText().toString().isEmpty()) {
            address_EditText.setError("Please enter full address");
            return;
        }
        if (address_EditText2.getText().toString().isEmpty()) {
            address_EditText2.setError("Please enter full address");
            return;
        }
        if (address_EditText3.getText().toString().isEmpty()) {
            address_EditText3.setError("Please enter address");
            return;

        }
        if (city_EditText.getText().toString().isEmpty()) {
            city_EditText.setError("Please enter City");
            return;
        }
        if (postal_Code_EditText.getText().toString().isEmpty()) {
            postal_Code_EditText.setError("Please enter Postal Code");
            return;
        }
        if (card_no_EditText.getText().toString().isEmpty()) {
            card_no_EditText.setError("Card no can't be Empty");
            return;
        }
        if (cvv_Edittext.getText().toString().isEmpty()) {
            cvv_Edittext.setError("cvv can't be Empty");
            return;
        }
        if (select_country_tv.getText().toString().equals(R.string.select_category)) {
            Toast.makeText(this, "Please Select your Country", Toast.LENGTH_SHORT).show();
            return;
        }
        if (select_card_tv.getText().toString().equals(R.string.card_type_string)) {
            Toast.makeText(this, "Please Select you card Type", Toast.LENGTH_SHORT).show();

        }


    }


}
