package com.doozycod.supremecheckout;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class SettingActivity extends AppCompatActivity {
    RelativeLayout add_product, checkout_tv, Saved_Product;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        add_product = findViewById(R.id.tv_add_product);
        checkout_tv = findViewById(R.id.tv_checkout);
        Saved_Product = findViewById(R.id.tv_saved_product);

        add_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingActivity.this, AddProduct.class));
            }
        });
        Saved_Product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingActivity.this, SavedProductActivity.class));
            }
        });
        checkout_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingActivity.this, CheckoutDetails.class));
            }
        });

    }
}