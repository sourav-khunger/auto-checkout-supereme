package com.doozycod.supremecheckout;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.doozycod.supremecheckout.Adapter.SavedProductAdapter;
import com.doozycod.supremecheckout.Helper.DbHelper;
import com.doozycod.supremecheckout.Helper.Model;

import java.util.ArrayList;
import java.util.List;

public class SavedProductActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Model> modelList;
    DbHelper dbHelper;
    SavedProductAdapter savedProductAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new DbHelper(this);
        setContentView(R.layout.activity_saved_product);
        modelList = new ArrayList<>();
        modelList = dbHelper.getDataForSavedProduct();

        recyclerView = findViewById(R.id.saved_product_recycler_list_view);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        savedProductAdapter = new SavedProductAdapter(this, modelList, dbHelper);
        recyclerView.setAdapter(savedProductAdapter);

    }
}
