package com.doozycod.supremecheckout;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.doozycod.supremecheckout.Helper.DbHelper;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ImageView setting_img;
    RelativeLayout search_btn, timer_btn;
    DbHelper dbHelper;
    ProgressDialog progressDialog;
    Cursor cursor;
    SQLiteDatabase db;

    List<String> categoryList = new ArrayList<>();
    List<String> productNameList = new ArrayList<>();
    List<String> product_Color_List = new ArrayList<>();
    List<String> product_Color_ID_List = new ArrayList<>();
    List<String> product_ID_List = new ArrayList<>();
    List<String> sizeList = new ArrayList<>();
    List<String> size_ID_List = new ArrayList<>();
    String search_product_id, search_color_id, search_size_id;
    String[] color_id_splitArray;
    String[] size_splitArray;
    Button Saved_Product;
    WebView webview;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dbHelper = new DbHelper(this);

        setContentView(R.layout.activity_main);

        progressDialog = new ProgressDialog(this);
        setting_img = findViewById(R.id.setting_btn);
        search_btn = findViewById(R.id.search_btn_relative);
        timer_btn = findViewById(R.id.timer_btn_relative);
        webview = findViewById(R.id.webView);


        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setTitle("Searching...");
                progressDialog.setCancelable(true);
                progressDialog.show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        db = dbHelper.getReadableDatabase();
                        categoryList.clear();
                        productNameList.clear();
                        product_Color_ID_List.clear();
                        sizeList.clear();
                        product_Color_List.clear();
                        product_ID_List.clear();
                        String query = "select * from " + DbHelper.TABLE_SPINNER_PRODUCT;
                        cursor = db.rawQuery(query, null);
                        if (cursor.moveToFirst()) {
                            do {
                                categoryList.add(cursor.getString(cursor.getColumnIndex("category_name")));
                                productNameList.add(cursor.getString(cursor.getColumnIndex("product_name")));
                                product_Color_List.add(cursor.getString(cursor.getColumnIndex("product_color")));
                                product_Color_ID_List.add(cursor.getString(cursor.getColumnIndex("color_id")));
                                product_ID_List.add(cursor.getString(cursor.getColumnIndex("product_id")));
                                sizeList.add(cursor.getString(cursor.getColumnIndex("product_size")));
                                size_ID_List.add(cursor.getString(cursor.getColumnIndex("size_id")));

                            } while (cursor.moveToNext());
                            searchFunction(product_ID_List, productNameList);
                        } else {
                            Toast.makeText(MainActivity.this, "Please Add Product!", Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }
                }, 2000);


            }
        });
        timer_btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetJavaScriptEnabled")
            @JavascriptInterface
            @Override
            public void onClick(View v) {
                jsonAPICheck(search_product_id, search_color_id, search_size_id);
                Log.e("Product :->", search_product_id + search_color_id + search_size_id);
            }
        });
        setting_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingActivity.class));
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void jsonAPICheck(String product_ID, final String style_ID, final String size_ID) {

        final String url = "https://www.supremenewyork.com/shop/" + 304209;



        try {


            webview.getSettings().setJavaScriptEnabled(true);
            webview.getSettings().setLoadWithOverviewMode(true);
            webview.getSettings().setUseWideViewPort(true);
            webview.loadUrl(url);


            webview.setWebViewClient(new WebViewClient() {
                //                final String js = ;
//
                final String js = "javascript:document.getElementById('size').value='" + size_ID + "';";
                final String js2 = "javascript:document.getElementById('data-style-id').value='" + 25802 + "';";

                final String js3 = "javascript:document.getElementById('commit').value='add to basket';" +
                        "document.getElementById('commit').click();";





//                final String js2 = "javascript:fetch(\"https://www.supremenewyork.com/shop/304195/add\", {\"credentials\":\"include\",\"headers\":{\"accept\":\"/;q=0.5, text/javascript, application/javascript, application/ecmascript, application/x-ecmascript\",\"accept-language\":\"en-DE,en;q=0.9,de-DE;q=0.8,de;q=0.7,en-US;q=0.6\",\"content-type\":\"application/x-www-form-urlencoded; charset=UTF-8\",\"x-csrf-token\":\"pJ838Tm+wmAU64Kcv7Km+xe0CAXU45Rvrdq8za0xV7Kvfaj2GftrGIE5Egx3ZXl1ssPznroqu98t2aRSER+p0Q==\",\"x-requested-with\":\"XMLHttpRequest\"},\"referrer\":\"https://www.supremenewyork.com/shop/tops-sweaters/oyeajgfs5/nlw8bnu96\",\"referrerPolicy\":\"no-referrer-when-downgrade\",\"body\":\"utf8=%E2%9C%93&style=25726&size=55027&commit=add+to+basket\",\"method\":\"POST\",\"mode\":\"cors\"});";

                public void onPageFinished(WebView view, String url) {



                    view.evaluateJavascript(js3, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {



                        }
                    });


                }
            });
//          webview.loadUrl("https://www.supremenewyork.com/shop/cart/");


      //     webview.loadUrl("http://www.supremenewyork.com/checkout");




        } catch (Exception e) {

            e.printStackTrace();
        }


    }

    private void searchFunction(List<String> product_ID_List, List<String> product_Name) {

        for (int index = 0; index < product_ID_List.size(); index++) {


            String searchData = "select * from " + DbHelper.TABLE_ALL_PRODUCTS + " where product_id= " + product_ID_List.get(index);

            cursor = db.rawQuery(searchData, null);

            //product available
            if (cursor.moveToFirst()) {

                String searched_product_color_id = cursor.getString(cursor.getColumnIndex("color_ids"));

                Log.e("Found Color ID", searched_product_color_id);

                if (searched_product_color_id.contains(",")) {

                    color_id_splitArray = searched_product_color_id.split(",");
                    Log.e("color_id_splitArray===>", color_id_splitArray.length + "");


                    for (String Color_id_split : color_id_splitArray) {


                        if (Color_id_split.equals(product_Color_ID_List.get(index))) {

                            String search_size_query = "select * from " + DbHelper.TABLE_FOR_PRODUCT_SIZE + " where color_ids=" + Color_id_split;

                            cursor = db.rawQuery(search_size_query, null);

                            if (cursor.moveToFirst()) {

                                do {
                                    String sizes = cursor.getString(cursor.getColumnIndex("all_sizes"));
                                    String color = cursor.getString(cursor.getColumnIndex("color_name"));
                                    String colorid = cursor.getString(cursor.getColumnIndex("color_ids"));

                                    Log.e("PRODUCT SIZE TABLE", colorid + " " + sizes + " " + color);
                                    if (sizes.contains(",")) {
                                        size_splitArray = sizes.split(",");

                                        for (String aSize_splitArray : size_splitArray) {


                                            if (aSize_splitArray.equals(sizeList.get(index))) {
                                                Toast.makeText(this, product_Name.get(index) + " Product Found! Ready to Checkout", Toast.LENGTH_SHORT).show();
                                                Log.e("Size_id", product_Name.get(index) + product_ID_List.get(index) + size_ID_List.get(index) + color + colorid);
                                                search_product_id = product_ID_List.get(index);
                                                search_color_id = colorid;
                                                search_size_id = size_ID_List.get(index);
                                                break;
                                            } else {
                                                Log.e("Product Check", aSize_splitArray + " === " + sizeList.get(index) + product_ID_List.get(index) + size_ID_List.get(index));

                                                Toast.makeText(this, "Not Found", Toast.LENGTH_SHORT).show();

                                            }
                                        }

                                    } else {
                                        Log.e("One Size Only ", sizes);

                                        if (sizes.equals(sizeList.get(index))) {
                                            Toast.makeText(this, product_Name.get(index) + " Product Found! Ready to Checkout", Toast.LENGTH_SHORT).show();


                                        }

                                    }


                                } while (cursor.moveToNext());
                            }
                        }


                    }
                } else {

                    Log.e("Single Color", searched_product_color_id);
                    if (searched_product_color_id.equals(product_Color_ID_List.get(index))) {

                        String search_size_query = "select * from " + DbHelper.TABLE_FOR_PRODUCT_SIZE + " where color_ids=" + searched_product_color_id;
                        cursor = db.rawQuery(search_size_query, null);

                        if (cursor.moveToFirst()) {

                            do {
                                String sizes = cursor.getString(cursor.getColumnIndex("all_sizes"));
                                String color = cursor.getString(cursor.getColumnIndex("color_name"));
                                String colorid = cursor.getString(cursor.getColumnIndex("color_ids"));


                                Log.e("Single Color Sizes", sizes);
                                if (sizes.contains(",")) {
                                    size_splitArray = sizes.split(",");

                                    for (String aSize_splitArray : size_splitArray) {


                                        if (aSize_splitArray.equals(sizeList.get(index))) {

                                            Log.e("Size", "Product Found");

                                        }
                                    }

                                } else {
                                    Log.e("One Size Only ", sizes);
                                }


                            } while (cursor.moveToNext());
                        }
                    }
                }


            } else {

//                progressDialog.dismiss();
                Toast.makeText(this, "product not available at this time.", Toast.LENGTH_SHORT).show();
            }

        }

    }


    public void viewAll() {
        Cursor res = dbHelper.getAllData(dbHelper.TABLE_ALL_PRODUCTS);
        if (res.getCount() == 0) {
            // show message
            showMessage("Error", "Nothing found");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append("Category :" + res.getString(1) + "\n");
            buffer.append("Product Name :" + res.getString(2) + "\n");
            buffer.append("product_id :" + res.getString(3) + "\n");
            buffer.append("product_price :" + res.getString(4) + "\n");
            buffer.append("sale_price :" + res.getString(5) + "\n");
            buffer.append("product_colors :" + res.getString(6) + "\n");
            buffer.append("color_ids :" + res.getString(7) + "\n\n");
        }

        // Show all data
        showMessage("Data", buffer.toString());


    }

    public void viewAll_size() {
        Cursor res = dbHelper.getAllData(DbHelper.TABLE_FOR_PRODUCT_SIZE);
        if (res.getCount() == 0) {
            // show message
            showMessage("Error", "Nothing found");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append("Color_ID:" + res.getString(1) + "\n");
            buffer.append("COLOR Name :" + res.getString(2) + "\n");
            buffer.append("All Sizes :" + res.getString(3) + "\n\n");
        }
        // Show all data
        showMessage("Data", buffer.toString());


    }

    public void viewAll_usr_product() {
        Cursor res = dbHelper.getAllData(DbHelper.TABLE_SPINNER_PRODUCT);
        if (res.getCount() == 0) {
            // show message
            showMessage("Error", "Nothing found");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append("Category:" + res.getString(1) + "\n");
            buffer.append("Product Name :" + res.getString(2) + "\n");
            buffer.append("Color :" + res.getString(3) + "\n");
            buffer.append("Size :" + res.getString(4) + "\n");
            buffer.append("product ID :" + res.getString(5) + "\n");
            buffer.append("Color ID:" + res.getString(6) + "\n");
            buffer.append("Size ID:" + res.getString(7) + "\n\n");
        }
        // Show all data
        showMessage("Data", buffer.toString());


    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}
