package com.doozycod.supremecheckout.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Products_Supreme.db";
    public static final String TABLE_ALL_PRODUCTS = "TABLE_ALL_PRODUCTS";
    public static final String TABLE_SPINNER_PRODUCT = "spinner_products";
    public static final String TABLE_FOR_PRODUCT_SIZE = "TABLE_PRODUCT_SIZE";


    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_ALL_PRODUCTS + "(column_id integer primary key, category_name text,product_name text, product_id text,product_price text,sale_price text,product_colors text,color_ids text)");
        db.execSQL("create table " + TABLE_SPINNER_PRODUCT + "(column_id integer primary key, category_name text,product_name text, product_color text,product_size text,product_id text,color_id text,size_id text)");
        db.execSQL("create table " + TABLE_FOR_PRODUCT_SIZE + "(column_id integer primary key,color_ids text,color_name text,all_sizes text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //    Creating a method to get product from history_prduct table
    public List<Model> getDataForSavedProduct() {

        // Declaring a List object
        List<Model> modelList = new ArrayList<>();

//        String for query
        String query = "select * from " + TABLE_SPINNER_PRODUCT;


        SQLiteDatabase db = this.getReadableDatabase();

//        creating cursor object to use query to get the data from table
        Cursor cursor = db.rawQuery(query, null);

//        Condition for set the data in pojo class
        if (cursor.moveToFirst()) {
            do {
//                creating DatabaseModel object to set the list using by Pojo
                Model model = new Model();
                model.setProductCategory((cursor).getString(1));
                model.setProductName((cursor).getString(2));
                model.setProductColor((cursor).getString(3));
                model.setProductSize((cursor).getString(4));
                model.setProduct_id((cursor).getString(5));
                modelList.add(model);
            } while (cursor.moveToNext());
        }


        Log.d("history data", modelList.toString());


        return modelList;
    }

    public void insert_product(String category_name, String product_name, String product_id, String product_price, String sale_price, String product_color, String color_id) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("category_name", category_name);
        cv.put("product_name", product_name);
        cv.put("product_id", product_id);
        cv.put("product_price", product_price);
        cv.put("sale_price", sale_price);
        cv.put("product_colors", product_color);
        cv.put("color_ids", color_id);

        db.insert(TABLE_ALL_PRODUCTS, null, cv);
        Log.e("Database ::", "Inserted in table!");

    }

    public Cursor getAllData(String table_name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + table_name, null);
        return res;
    }

    public void deleteEntry(String product_id) {

        SQLiteDatabase ourDatabase = this.getWritableDatabase();
        ourDatabase.delete(TABLE_SPINNER_PRODUCT, "product_id" + " = '" + product_id + "'", null);
        Log.e("Deleted!", product_id);
    }

    public void update_product(String product_id, String product_colors, String color_id) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("color_ids", color_id);
        cv.put("product_colors", product_colors);

        db.update(TABLE_ALL_PRODUCTS, cv, "product_id=" + product_id, null);
        Log.e("Database ::", "Updated in table!");

    }

    public void save_product_size(String color_id, String color_name, String product_sizes) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("color_ids", color_id);
        cv.put("color_name", color_name);
        cv.put("all_sizes", product_sizes);

        db.insert(TABLE_FOR_PRODUCT_SIZE, null, cv);


    }

    public void update_size_in_table(String color_id, String all_sizes) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("all_sizes", all_sizes);
        database.update(TABLE_FOR_PRODUCT_SIZE, contentValues, "color_ids=" + color_id, null);
        Log.e("Database ::", "Updated in Sizes table!");


    }

    public void save_product_from_settings(String category_name, String product_name, String product_color_name, String product_size, String color_id, String product_id, String size_id) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("category_name", category_name);
        contentValues.put("product_name", product_name);
        contentValues.put("product_color", product_color_name);
        contentValues.put("product_size", product_size);
        contentValues.put("color_id", color_id);
        contentValues.put("product_id", product_id);
        contentValues.put("size_id", size_id);
        sqLiteDatabase.insert(TABLE_SPINNER_PRODUCT, null, contentValues);
        Log.e("Database ::", "Inserted in table! in SPINNER PRODUCT!");

    }

}
